@extends('template.base')
@section('content')
    <h1>Beranda</h1>
    <br>
    <h5>Halo, nama saya Anggeralmasih Wiradika Rusmana, biasa dipanggil Angger.</h5>
    <p>Saya mahasiswa Intitut Teknologi Telkom Purwokerto jurusan S1 Rekayasa Perangkat Lunak.</p>
@endsection
