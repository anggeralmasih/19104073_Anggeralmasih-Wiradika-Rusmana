<?php $__env->startSection('content'); ?>
    <h1>About</h1>
    <p>Ini adalah Praktikum pemrograman web yang mempelajari Framework PHP yaitu Laravel</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\Praktikum Pemrograman WEB\Pertemuan 6\example-app\resources\views/about.blade.php ENDPATH**/ ?>